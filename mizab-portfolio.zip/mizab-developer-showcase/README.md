# Syed Mizab Ali Shah — Premium Developer Portfolio

A responsive dark-and-purple developer portfolio featuring CSS illustrations, subtle animations, and three functional demonstration projects.

## Projects
- Task Manager — HTML/CSS/JavaScript, localStorage
- Expense Tracker — HTML/CSS/JavaScript, localStorage + CSV export
- Student Record Manager — Java console app, local CSV persistence

## Preview
Open `index.html` in a browser. Google Fonts require an internet connection; fallback fonts work offline.

## Publish on GitHub Pages
1. Create a public GitHub repository.
2. Upload the **contents** of this folder, keeping `index.html` in the repository root.
3. Go to Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
4. Once published, use the provided public URL where permitted by Fiverr.

## Note
These are demonstration projects, not commissioned client work. Review and customize the code before using it to advertise your skills.
