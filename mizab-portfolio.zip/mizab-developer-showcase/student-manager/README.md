# Student Record Manager (Java)

A Java command-line application for adding, listing, searching, and deleting student records. Records are stored in a local `students.csv` file (names are Base64-encoded to keep commas/newlines safe; this is not encryption).

## Requirements
Java JDK 8 or newer.

## Run
```bash
cd student-manager
javac StudentManager.java
java StudentManager
```

This is a console app and cannot run directly on GitHub Pages.
