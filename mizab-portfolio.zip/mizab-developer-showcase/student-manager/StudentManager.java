import java.io.*;
import java.nio.file.*;
import java.util.*;

public class StudentManager {
    private static final Path FILE = Paths.get("students.csv");
    private static final Scanner INPUT = new Scanner(System.in);
    private static final Map<Integer, Student> students = new LinkedHashMap<>();
    static class Student {
        int id; String name; double grade;
        Student(int id, String name, double grade) { this.id=id; this.name=name; this.grade=grade; }
    }
    public static void main(String[] args) {
        load();
        while (true) {
            System.out.println("\n1 Add  2 List  3 Search  4 Delete  5 Exit");
            int option = readInt("Choose: ");
            switch(option) {
                case 1: add(); break;
                case 2: list(); break;
                case 3: { Student s=students.get(readInt("Student ID: ")); if(s==null) System.out.println("Not found"); else print(s); break; }
                case 4: { int id=readInt("Student ID: "); System.out.println(students.remove(id)!=null?"Deleted":"Not found"); save(); break; }
                case 5: save(); System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option");
            }
        }
    }
    static int readInt(String prompt) { while(true) { System.out.print(prompt); try { return Integer.parseInt(INPUT.nextLine().trim()); } catch(NumberFormatException e) { System.out.println("Enter a whole number."); } } }
    static double readGrade() { while(true) { System.out.print("Grade (0-100): "); try { double n=Double.parseDouble(INPUT.nextLine().trim()); if(Double.isFinite(n)&&n>=0&&n<=100)return n; } catch(NumberFormatException ignored) {} System.out.println("Enter a valid grade from 0 to 100."); } }
    static void add() { int id=readInt("Student ID: "); if(students.containsKey(id)) { System.out.println("ID already exists."); return; } System.out.print("Name: "); String name=INPUT.nextLine().trim(); if(name.isEmpty()) { System.out.println("Name required."); return; } double grade=readGrade(); students.put(id,new Student(id,name,grade)); save(); System.out.println("Saved."); }
    static void list() { if(students.isEmpty()) System.out.println("No students yet."); else students.values().forEach(StudentManager::print); }
    static void print(Student s) { System.out.printf("ID: %d | Name: %s | Grade: %.1f%n",s.id,s.name,s.grade); }
    static void load() { if(!Files.exists(FILE))return; try(BufferedReader reader=Files.newBufferedReader(FILE)) { String line; while((line=reader.readLine())!=null) { String[] p=line.split(",",3); if(p.length==3) { try { int id=Integer.parseInt(p[0]); double grade=Double.parseDouble(p[1]); String name=new String(Base64.getDecoder().decode(p[2]),java.nio.charset.StandardCharsets.UTF_8); students.put(id,new Student(id,name,grade)); }catch(IllegalArgumentException ignored){} } } }catch(IOException e){System.out.println("Could not load saved records: "+e.getMessage());} }
    static void save() { try(BufferedWriter writer=Files.newBufferedWriter(FILE)) { for(Student s:students.values()) { String encoded=Base64.getEncoder().encodeToString(s.name.getBytes(java.nio.charset.StandardCharsets.UTF_8)); writer.write(s.id+","+s.grade+","+encoded); writer.newLine(); } }catch(IOException e){System.out.println("Could not save records: "+e.getMessage());} }
}
